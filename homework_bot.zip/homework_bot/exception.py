class MissingVariable(Exception):
    pass


class KeyNotFound(Exception):
    pass


class UnknownStatus(Exception):
    pass
